mod binary_domain;
mod problem;
pub mod problems;
mod solver;

pub use solver::IfdsSolver;
